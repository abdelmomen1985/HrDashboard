self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "113e86f9dddd534f9ce2b85ad34aea40",
    "url": "/hrboard/index.html"
  },
  {
    "revision": "7bd39fbd393aa3ae0d7d",
    "url": "/hrboard/static/css/main.e51cc356.chunk.css"
  },
  {
    "revision": "97a87055a089d61ddf81",
    "url": "/hrboard/static/js/2.0d16e974.chunk.js"
  },
  {
    "revision": "278be41389e3536a5347a9018737729d",
    "url": "/hrboard/static/js/2.0d16e974.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7bd39fbd393aa3ae0d7d",
    "url": "/hrboard/static/js/main.01467e62.chunk.js"
  },
  {
    "revision": "43534a5721c88ede740a",
    "url": "/hrboard/static/js/runtime-main.9a594967.js"
  },
  {
    "revision": "1a2d897ca4831c253c8f99d18443f16f",
    "url": "/hrboard/static/media/ElMessiri-Bold.1a2d897c.ttf"
  },
  {
    "revision": "1e2cb99020914faebd543c1ef2dccf84",
    "url": "/hrboard/static/media/ElMessiri-SemiBold.1e2cb990.ttf"
  },
  {
    "revision": "de2bd26533da108f04ceb9aea79d10d4",
    "url": "/hrboard/static/media/branches.de2bd265.svg"
  },
  {
    "revision": "87b0b6230c112d0143c1cdc275586c06",
    "url": "/hrboard/static/media/conversations.87b0b623.svg"
  },
  {
    "revision": "d2c5085017542198ebbb6f4aa027d855",
    "url": "/hrboard/static/media/employees.d2c50850.svg"
  },
  {
    "revision": "2bb6ee52a2f406ee25fc32f35514c414",
    "url": "/hrboard/static/media/inout.2bb6ee52.svg"
  },
  {
    "revision": "675bc05218d235b4adca42cfe010a5b5",
    "url": "/hrboard/static/media/location_searching.675bc052.svg"
  },
  {
    "revision": "afd6cbf478a49496883ae6fe41b2ffc8",
    "url": "/hrboard/static/media/vacations.afd6cbf4.svg"
  }
]);